<?php
include_once 'inc/config.inc.php';
include_once 'inc/mysql.inc.php';
include_once 'inc/tool.inc.php';
$link=connect();

$member_id=is_login($link);
if($member_id){
    skip('index.php','error','你已经登录，请不要重复登录！');
}

    if(isset($_POST['submit'])){
       
        escape($link,$_POST);
        $query="select * from CM_register where register_name='{$_POST['name']}' and register_password=md5('{$_POST['pw']}')";
        $result=execute($link, $query);
        include 'inc/check_login.inc.php';
}

?>
<?php 
include_once 'inc/head.inc.php';?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>denglujiemian</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
</head>
<body>

	
	<div style="margin-top:55px;"></div>
	<div id="register" class="auto">
		<h2>欢迎用户登录</h2>
		<form method= "post">
			<label>用户名：<input type="text" name="name" /> </label>
			<label>密码：<input type="password" name="pw" />  </label>
            <select name="member_id" >
                <option>学生</option>
                <option>管理员</option>
                <option>院系管理</option>

            </select>
		
			
		
			
			 
		 
		 
			<input class="btn" type="submit" name="submit" value="登陆" />
		</form>
	</div>
</body>

</html>