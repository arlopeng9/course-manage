<?php
include_once 'inc/tool.inc.php';
include_once 'inc/mysql.inc.php';
include_once 'inc/config.inc.php';
$link=connect();
$member_id=is_login($link);

if(isset($_POST['submit'])){
    if($_POST['member_id']=='管理员' or $_POST['member_id']=='院系管理'){
        skip('login.php','error','非法字符！');
    }
    $link=connect();
    INCLUDE 'inc/check_register.inc.php';
    $_POST=escape($link,$_POST);
    $query="insert into CM_register(register_name,register_password,register_id,register_mail,register_work) values('{$_POST['name']}',md5('{$_POST['pw']}'),'{$_POST['member_id']}','{$_POST['member_mail']}','学生')";
    execute($link, $query);
    if(mysqli_affected_rows($link)==1){
        setcookie('cookie[name]',$_POST['name']);
        setcookie('cookie[pw]',sha1(md5($_POST['pw'])));
        setcookie('cookie[member_id]',$_POST['member_id']);
        skip('index.php','ok','注册成功！');
    }else{
        skip('register.php','eror','注册失败,请重试！');
    }
   
    
}
?>
<?php 
include_once 'inc/head.inc.php';?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<!-- <link rel="stylesheet" type="text/css" href="style/register.css" /> -->
</head>
<body>
	
	
	
		<h2>课程管理系统</h2>
		<form method= "post">
			<label>账号：<input type="text" name="name" /></label>
			<label>密码：<input type="password" name="pw" /></label>
			<label>确认密码：<input type="password" name="confirm_pw" /></label>
            <label>用户名字：<input type="text" name="member_id" /></label>
			<label>电子邮箱：<input type="text" name="member_mail" /></label>

			
			
			<input class="btn" name="submit" type="submit" value="确定注册" />
		</form>

</body>
</html>
