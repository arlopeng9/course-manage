<?php
echo 'hellow word';
phpinfo();