//<?php 

// $_POST=escape($link,$_POST);
// switch ($check_flag){
// 	case 'add':
// 		$query="select * from CM_course where course_name='{$_POST['course_name']}'";
// 		break;
// 	case 'update':
// 		$query="select * from CM_course where course_name='{$_POST['course_name']}' and cID!={$_GET['id']}";
// 		break;
// 	default:
// 		skip('father_module_add.php','error','$check_flag参数错误！');
// }

// ?>