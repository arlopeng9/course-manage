<?php
session_start();
header('Content-type:text/html;charset=utf-8');
define('DB_HOST','cdb-5oviul9n.gz.tencentcdb.com');
define('DB_USER','root');
define('DB_PASSWORD','Ab123123');
define('DB_DATABASE','class_manage');
define('DB_PORT',10094);
$IDman=1;
$GLOBALS['IDman'];

define('SA_PATH',dirname(dirname(__FILE__)));
define('SUB_URL','/test/');





?>