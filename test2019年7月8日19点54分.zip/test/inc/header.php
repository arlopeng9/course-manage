 <div class="col-md-2">
                            <nav>
                                <div class="king-vertical-nav6  m0 ">
                              
                                   <div>
                                        <div class="nav-header">
                                            <span class="glyphicon fa fa-fw fa-institution logo"></span>
                                            <span>个人信息</span>
                                        </div>
                                        <ul class="nav-list"style=margin-bottom:400>
                                            <li class="active">
                                                <a href="class1.php" title="已选课程"> <i class=" fa fa-fw fa-newspaper-o"></i>
                                                    <span>已选课程</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="xueji.php" title="学籍绑定"> <i class=" fa fa-fw fa-gear"></i>
                                                    <span>学籍绑定</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="xuanze.php" title="选择课程"> <i class=" fa fa-fw fa-laptop"></i>
                                                    <span>选择课程</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="person.php" title="个人中心"> <i class=" fa fa-fw fa-laptop"></i>
                                                    <span>个人中心</span>
                                                </a>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </div>