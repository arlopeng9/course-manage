<head>
	<meta charset="UTF-8">
	<meta name='TTUNION_verify' content='b846c3c2b85efabc496d2a2b8399cd62'>
	<meta name="sogou_site_verification" content="gI1bINaJcL"/>
	<meta name="360-site-verification" content="37ae9186443cc6e270d8a52943cd3c5a"/>
	<meta name="baidu_union_verify" content="99203948fbfbb64534dbe0f030cbe817">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="apple-touch-fullscreen" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE;chrome=1">
	<meta name="format-detection" content="telephone=no">
	<meta name="keywords" content="">
	<meta name="description" content="。">
	<meta name="author" content="AUI, a-ui.com">
	<meta name="baidu-site-verification" content="ZVPGgtpUfW"/>
	<title>已选课程查看</title>
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<link href="iTunesArtwork@2x.png" sizes="114x114" rel="apple-touch-icon-precomposed">
	<link type="text/css" rel="stylesheet" href="person/css/core.css">
	<link type="text/css" rel="stylesheet" href="person/css/icon.css">
	<link type="text/css" rel="stylesheet" href="person/css/home.css">


</head>
<body bgcolor = "">
<section>
		<div class="ydc-content-slide ydc-body">
			<div class="ydc-flex">
				<!-- left begin -->
				<div class="ydc-column ydc-column-2">
					<div class="ydc-menu">
						<ul>
						
							<li class="ydc-menu-item">
								<a href="/test/index.php"  ><i class="ydc-icon ydc-icon-home fl"></i>首页</a>
							</li>
							<li class="ydc-menu-item">
								<a href="person.php"   <?php if($php=='person'){echo 'class="active"';}?>><i class="ydc-icon ydc-icon-find fl"></i>个人中心首页</a>
							</li>
							<li class="ydc-menu-item">
								<span class="ydc-menu-sub-title">
									<i class="ydc-icon ydc-icon-file fl"></i>课程管理
								</span>
								<ul>
									<li>
										<a href="class1.php" title="已选课程" <?php if($php=='class1'){echo 'class="active"';}?> > <i class=" fa fa-fw fa-newspaper-o"></i>
                    					<span>已选课程查看</span>
                                        </a>
									</li>
									<li>
										<a href="xuanze.php" title="选择课程"<?php if($php=='xuanze'){echo 'class="active"';}?>> <i class=" fa fa-fw fa-laptop"></i>
                                            <span>选择课程</span>
                                        </a>
									</li>
								</ul>
							</li>
							<li class="ydc-menu-item">
								<span class="ydc-menu-sub-title">
									<i class="ydc-icon ydc-icon-record fl"></i>课程学习数据
								</span>
								<ul>
									<li>
										<a href="lishi.php" title="学习历史"<?php if($php=='lishi'){echo 'class="active"';}?>> <i class=" fa fa-fw fa-gear"></i>
                                        <span>学习历史</span>
                                         </a>
									</li>
									
									
								</ul>
							</li>
							<li class="ydc-menu-item">
								<span class="ydc-menu-sub-title">
									<i class="ydc-icon ydc-icon-set fl"></i>设置
								</span>
								<ul>
									<li>
										<a href="zhanghao.php" title="账号信息"<?php if($php=='zhanghao'){echo 'class="active"';}?>> <i class=" fa fa-fw fa-gear"></i>
                                        <span>账号信息</span>
                                         </a>
									</li>
									</ul>
									<ul>
									<li>
										<a href="xueji.php" title="学籍绑定"<?php if($php=='xueji'){echo 'class="active"';}?>> <i class=" fa fa-fw fa-gear"></i>
                                        <span>学籍绑定</span>
                                        </a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
				<!-- left end -->